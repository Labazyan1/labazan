<?php
// ШАБЛОН. На сервере Beget скопируй этот файл в lead-config.php (без .sample)
// и впиши свои значения. Файл lead.php подхватит их автоматически.
//
// Где взять:
//   BOT_TOKEN — у @BotFather после /newbot
//   CHAT_ID   — твой числовой id (узнать у @userinfobot). Не забудь нажать
//               Start у своего бота, иначе он не сможет тебе писать.

$BOT_TOKEN = '123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
$CHAT_ID   = '123456789';
