<?php
// Обработчик заявки для российского хостинга (Beget).
// Принимает POST из формы сайта и отправляет заявку в Telegram.
// Персональные данные обрабатываются на сервере в РФ (152-ФЗ).

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Секреты лежат в отдельном файле lead-config.php (его создаёшь на сервере).
$BOT_TOKEN = '';
$CHAT_ID = '';
foreach ([__DIR__ . '/lead-config.php', __DIR__ . '/../lead-config.php'] as $cfg) {
    if (is_file($cfg)) { require $cfg; break; }
}

function out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function clean($v, $max = 500) {
    $v = is_string($v) ? $v : '';
    $v = preg_replace('/[<>]/', '', $v);
    return mb_substr(trim($v), 0, $max);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    out(['ok' => false, 'error' => 'method'], 405);
}

// Honeypot: бот заполнит скрытое поле — молча принимаем и игнорируем.
if (clean($_POST['company'] ?? '', 100) !== '') {
    out(['ok' => true]);
}

$name    = clean($_POST['name'] ?? '', 120);
$contact = clean($_POST['contact'] ?? '', 160);
$task    = clean($_POST['task'] ?? '', 1500);

if ($name === '' || $contact === '') {
    out(['ok' => false, 'error' => 'validation'], 422);
}

if ($BOT_TOKEN === '' || $CHAT_ID === '') {
    out(['ok' => false, 'error' => 'not_configured'], 503);
}

$text = "🟠 Новая заявка с labazan.ru\n\n"
      . "Имя: {$name}\n"
      . "Контакт: {$contact}\n"
      . "Задача: " . ($task !== '' ? $task : '—');

$payload = http_build_query([
    'chat_id' => $CHAT_ID,
    'text' => $text,
    'disable_web_page_preview' => 'true',
]);

$url = "https://api.telegram.org/bot{$BOT_TOKEN}/sendMessage";
$httpCode = 0;

if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 15,
    ]);
    curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
} else {
    // Запасной путь, если cURL выключен на хостинге.
    $ctx = stream_context_create(['http' => [
        'method' => 'POST',
        'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => $payload,
        'timeout' => 15,
    ]]);
    $res = @file_get_contents($url, false, $ctx);
    $httpCode = $res !== false ? 200 : 0;
}

if ($httpCode === 200) {
    out(['ok' => true]);
}
out(['ok' => false, 'error' => 'telegram'], 502);
